<div class="message-none">
    <div> <?php echo ossn_print('no:messages'); ?></div>
</div>
