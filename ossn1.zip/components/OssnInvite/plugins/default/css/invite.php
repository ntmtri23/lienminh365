.ossn-invite-friends {
	background: #fff;
	padding: 10px;
}
.ossn-invite-friends input[type='submit']{
	margin-top:10px;
}
