.ossn-ad-tiem-small {
margin-bottom:20px;
}
.ossn-ad-tiem-small img{
display:block;
}
.ossn-ad-tiem-small .descript{
display:block;
margin-top:5px;
}
.ad-heading {
width:127px;
}
.ad-heading a{
font-size:12px;
font-weight:bold;
}
.ossn-ad-tiem-small .ossn-ads-link {
font-size: 11px;
margin-bottom: 5px;
margin-top: 3px;
width: 100px;
}
.ossn-ads .sponsered {
margin-top: 8px;
margin-bottom: 5px;
font-weight: bold;
color: #999;
}
.ossn-ads-small {
width: 125px !important;
}