.ossn-ad-image {
  width:200px;
  height:200px;
}