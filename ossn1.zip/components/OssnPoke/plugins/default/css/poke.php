.ossn-notification-icon-poke {
background: url('<?php echo ossn_site_url(); ?>components/OssnPoke/images/poke.png') no-repeat;
width: 18px;
height: 18px;
position: absolute;
}