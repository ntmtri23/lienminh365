.ossn-like-icon {
	background:url('<?php echo ossn_site_url(); ?>components/OssnLikes/images/like.png') no-repeat;
	width:14px;
	height:15px;
	margin-right:3px;
	display:inline-block;
}
.dot-likes {
	vertical-align: top;
	margin: -1px 5px 0 0px;
	display: inline-block;
}