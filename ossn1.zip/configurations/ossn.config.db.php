<?php
/**
 * Open Source Social Network
 *
 * @package   (Informatikon.com).ossn
 * @author    OSSN Core Team <info@opensource-socialnetwork.org>
 * @copyright 2014 iNFORMATIKON TECHNOLOGIES
 * @license   General Public Licence http://www.opensource-socialnetwork.org/licence
 * @link      http://www.opensource-socialnetwork.org/licence
 */


// replace localhost with your database host name;
$Ossn->host = '203.162.242.94';

// replace root with your database username;
$Ossn->user = 'lienminh365';

// replace  with your database password;
$Ossn->password = '8VLUZy4SNQqyeee7';

// replace social with your database name;
$Ossn->database = 'lienminh365';