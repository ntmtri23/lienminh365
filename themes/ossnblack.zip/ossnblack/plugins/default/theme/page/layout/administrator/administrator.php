<div class="ossn-layout-admin">
	<div class="row ossn-system-messages">
		 <?php echo ossn_display_system_messages(); ?>
	</div>
	<div class="row">
		<div class="page-title"><?php echo $params['title']; ?></div>
    	<div class="col-md-12 contents">
    	 	<?php echo $params['contents']; ?>
    	</div>
	</div>
</div>    