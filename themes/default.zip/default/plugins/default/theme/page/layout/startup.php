<div class="ossn-home-container">
    <div class="inner">
        <?php echo $params['content']; ?>
    </div>
</div>